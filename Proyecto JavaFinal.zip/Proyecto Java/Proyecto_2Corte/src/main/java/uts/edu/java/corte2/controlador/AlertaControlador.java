package uts.edu.java.corte2.controlador;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import uts.edu.java.corte2.modelo.Alerta;
import uts.edu.java.corte2.modelo.Dispositivo;
import uts.edu.java.corte2.modelo.Menor;
import uts.edu.java.corte2.servicio.IAlertaServicio;
import uts.edu.java.corte2.servicio.IDispositivoServicio;
import uts.edu.java.corte2.servicio.IMenorServicio;

@Controller
@RequestMapping("/views/alerta")
public class AlertaControlador {

    @Autowired
    private IAlertaServicio alertaServicio;

    @Autowired
    private IDispositivoServicio dispositivoServicio;

    @Autowired
    private IMenorServicio menorServicio;

    @GetMapping("/")
    public String listar(Model model) {
        model.addAttribute("listaAlertas", alertaServicio.listarTodas());
        return "/views/alerta/alerta";
    }

    @GetMapping("/new")
    public String nuevo(Model model) {
        model.addAttribute("alerta", new Alerta());
        model.addAttribute("dispositivos", dispositivoServicio.getDispositivos());
        model.addAttribute("menores", menorServicio.getMenores());
        return "/views/alerta/nuevo_alerta";
    }

    @PostMapping("/save")
    public String guardar(@ModelAttribute("alerta") Alerta alerta) {
        
    	Long idMenor = alerta.getMenor().getIdniño();
        Menor menor = menorServicio.listarId(idMenor);
        alerta.setMenor(menor);

        Long idDispositivo = alerta.getDispositivo().getIddispositivo();
        Dispositivo disp = dispositivoServicio.listarId(idDispositivo);
        alerta.setDispositivo(disp);

        alertaServicio.guardar(alerta);

        return "redirect:/views/alerta/";
    }
    

    @GetMapping("/listar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("alerta", alertaServicio.listarPorId(id));
        model.addAttribute("dispositivos", dispositivoServicio.getDispositivos());
        model.addAttribute("menores", menorServicio.getMenores());
        return "/views/alerta/editar_alerta";
    }

    @GetMapping("/delete/{id}")
    public String eliminar(@PathVariable Long id) {
        alertaServicio.eliminar(id);
        return "redirect:/views/alerta/";
    }
}
