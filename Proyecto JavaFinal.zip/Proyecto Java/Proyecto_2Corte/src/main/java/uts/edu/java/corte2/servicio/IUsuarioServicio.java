package uts.edu.java.corte2.servicio;

	import java.util.List;
	import uts.edu.java.corte2.modelo.Usuario;

	public interface IUsuarioServicio {

	    // Listar todos los usuarios
	    List<Usuario> getUsuarios();

	    // Buscar por ID
	    Usuario listarId(Long id);

	    // Crear o actualizar usuario
	    Usuario save(Usuario usuario);

	    // Eliminar usuario
	    void delete(Long id);
	}

