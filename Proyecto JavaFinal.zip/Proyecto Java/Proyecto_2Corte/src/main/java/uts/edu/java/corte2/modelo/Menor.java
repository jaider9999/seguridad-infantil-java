package uts.edu.java.corte2.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "menor")
public class Menor {

    // ---------- Atributos ----------
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idniño")
    private Long idniño;

    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    @Column(name = "edad")
    private int edad;

    // Relación con dispositivo (N:1)
    @ManyToOne
    @JoinColumn(name = "iddispositivo")
    private Dispositivo dispositivo;

    // Relación con usuario (el padre o tutor)
    @ManyToOne
    @JoinColumn(name = "idusuario")
    private Usuario usuario;


    // ---------- Constructores ----------
    public Menor() {
    }

  
    public Menor(Long idniño, String nombre, int edad, Dispositivo dispositivo, Usuario usuario) {
		super();
		this.idniño = idniño;
		this.nombre = nombre;
		this.edad = edad;
		this.dispositivo = dispositivo;
		this.usuario = usuario;
	}



	// ---------- Getters y Setters ----------
    public Long getIdniño() {
        return idniño;
    }

    public void setIdniño(Long idniño) {
        this.idniño = idniño;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }


    public Dispositivo getDispositivo() {
        return dispositivo;
    }

    public void setDispositivo(Dispositivo dispositivo) {
        this.dispositivo = dispositivo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}
