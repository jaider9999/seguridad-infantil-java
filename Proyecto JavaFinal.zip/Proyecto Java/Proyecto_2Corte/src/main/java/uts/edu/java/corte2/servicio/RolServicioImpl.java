package uts.edu.java.corte2.servicio;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uts.edu.java.corte2.modelo.Rol;
import uts.edu.java.corte2.repositorio.RolRepositorio;

@Service
public class RolServicioImpl implements RolServicio {

    @Autowired
    private RolRepositorio rolRepositorio;

    @Override
    public List<Rol> getRoles() {
        return rolRepositorio.findAll();
    }

    @Override
    public void save(Rol rol) {
        rolRepositorio.save(rol);
    }

    @Override
    public Rol listarId(int id) {
        return rolRepositorio.findById(id).orElse(null);
    }

    @Override
    public void delete(int id) {
        rolRepositorio.deleteById(id);
    }
}

