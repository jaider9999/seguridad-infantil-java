package uts.edu.java.corte2.servicio;


import java.util.List;
import uts.edu.java.corte2.modelo.Ruta;

public interface IRutaServicio {
    List<Ruta> listarTodas();
    Ruta listarPorId(Long id);
    void guardar(Ruta ruta);
    void eliminar(Long id);
}
