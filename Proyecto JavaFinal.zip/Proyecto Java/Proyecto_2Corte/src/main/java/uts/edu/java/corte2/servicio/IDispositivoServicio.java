package uts.edu.java.corte2.servicio;

import java.util.List;
import uts.edu.java.corte2.modelo.Dispositivo;

public interface IDispositivoServicio {

    // Listar todos los dispositivos
    List<Dispositivo> getDispositivos();

    // Buscar por ID
    Dispositivo listarId(Long id);

    // Crear o actualizar dispositivo
    Dispositivo save(Dispositivo dispositivo);

    // Eliminar dispositivo
    void delete(Long id);
}
