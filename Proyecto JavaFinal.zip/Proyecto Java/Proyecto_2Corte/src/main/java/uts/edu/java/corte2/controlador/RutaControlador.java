package uts.edu.java.corte2.controlador;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import uts.edu.java.corte2.modelo.Ruta;
import uts.edu.java.corte2.servicio.IRutaServicio;

@Controller
@RequestMapping("/views/ruta")
public class RutaControlador {

    @Autowired
    private IRutaServicio rutaServicio;

    @GetMapping("/")
    public String listar(Model model) {
        List<Ruta> listaRutas = rutaServicio.listarTodas();
        model.addAttribute("listaRutas", listaRutas);
        return "/views/ruta/ruta";
    }

    @GetMapping("/new")
    public String nuevo(Model model) {
        model.addAttribute("ruta", new Ruta());
        return "/views/ruta/nuevo_ruta";
    }

    @PostMapping("/save")
    public String guardar(@ModelAttribute Ruta ruta) {
        rutaServicio.guardar(ruta);
        return "redirect:/views/ruta/";
    }

    @GetMapping("/listar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("ruta", rutaServicio.listarPorId(id));
        return "/views/ruta/editar_ruta";
    }

    @GetMapping("/delete/{id}")
    public String eliminar(@PathVariable Long id) {
        rutaServicio.eliminar(id);
        return "redirect:/views/ruta/";
    }
}
