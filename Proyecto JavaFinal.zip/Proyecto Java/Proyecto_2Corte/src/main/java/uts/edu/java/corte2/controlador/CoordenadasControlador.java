package uts.edu.java.corte2.controlador;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import uts.edu.java.corte2.modelo.Coordenadas;
import uts.edu.java.corte2.servicio.ICoordenadasServicio;
import uts.edu.java.corte2.servicio.IRutaServicio;

@Controller
@RequestMapping("/views/coordenadas")
public class CoordenadasControlador {

    @Autowired
    private ICoordenadasServicio coordenadasServicio;

    @Autowired
    private IRutaServicio rutaServicio;

    @GetMapping("/")
    public String listar(Model model) {
        List<Coordenadas> listaCoordenadas = coordenadasServicio.listarTodas();
        model.addAttribute("listaCoordenadas", listaCoordenadas);
        return "/views/coordenadas/coordenadas";
    }

    @GetMapping("/new")
    public String nuevo(Model model) {
        model.addAttribute("coordenadas", new Coordenadas());
        model.addAttribute("rutas", rutaServicio.listarTodas());
        return "/views/coordenadas/nuevo_coordenadas";
    }

    @PostMapping("/save")
    public String guardar(@ModelAttribute Coordenadas coordenadas) {
        coordenadasServicio.guardar(coordenadas);
        return "redirect:/views/coordenadas/";
    }

    @GetMapping("/listar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("coordenadas", coordenadasServicio.listarPorId(id));
        model.addAttribute("rutas", rutaServicio.listarTodas());
        return "/views/coordenadas/editar_coordenadas";
    }

    @GetMapping("/delete/{id}")
    public String eliminar(@PathVariable Long id) {
        coordenadasServicio.eliminar(id);
        return "redirect:/views/coordenadas/";
    }
}
