package uts.edu.java.corte2.servicio;

import java.util.List;
import uts.edu.java.corte2.modelo.Rol;

public interface RolServicio {
    List<Rol> getRoles();
    void save(Rol rol);
    Rol listarId(int id);
    void delete(int id);
}
