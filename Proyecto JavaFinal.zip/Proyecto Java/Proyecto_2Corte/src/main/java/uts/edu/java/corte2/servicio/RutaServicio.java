package uts.edu.java.corte2.servicio;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uts.edu.java.corte2.modelo.Ruta;
import uts.edu.java.corte2.repositorio.RutaRepositorio;

@Service
public class RutaServicio implements IRutaServicio {

    @Autowired
    private RutaRepositorio rutaRepositorio;

    @Override
    public List<Ruta> listarTodas() {
        return rutaRepositorio.findAll();
    }

    @Override
    public Ruta listarPorId(Long id) {
        return rutaRepositorio.findById(id).orElse(null);
    }

    @Override
    public void guardar(Ruta ruta) {
        rutaRepositorio.save(ruta);
    }

    @Override
    public void eliminar(Long id) {
        rutaRepositorio.deleteById(id);
    }
}
