package uts.edu.java.corte2.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import uts.edu.java.corte2.modelo.Rol;
import uts.edu.java.corte2.servicio.RolServicio;

@Controller
@RequestMapping("/views/rol")
public class RolControlador {

    @Autowired
    private RolServicio rolServicio;

    // Mostrar lista de roles
    @RequestMapping("/")
    public String verIndex(Model model) {
        List<Rol> listaRoles = rolServicio.getRoles();
        model.addAttribute("listaRoles", listaRoles);
        return "/views/rol/rol";
    }

    // Formulario nuevo rol
    @RequestMapping("/new")
    public String mostrarPaginaNuevoRol(Model model) {
        Rol rol = new Rol();
        model.addAttribute("rol", rol);
        return "/views/rol/nuevo_rol";
    }

    // Guardar rol
    @PostMapping("/save")
    public String saveRol(Rol rol) {
        rolServicio.save(rol);
        return "redirect:/views/rol/";
    }

    // Editar rol
    @GetMapping("/listar/{id}")
    public String listarId(@PathVariable int id, Model model) {
        model.addAttribute("rol", rolServicio.listarId(id));
        return "/views/rol/editar_rol";
    }

    // Eliminar rol
    @RequestMapping("/delete/{id}")
    public String deleteRol(@PathVariable int id) {
        rolServicio.delete(id);
        return "redirect:/views/rol/";
    }
}
