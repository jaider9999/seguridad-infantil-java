package uts.edu.java.corte2.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "coordenadas")
public class Coordenadas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idcoordenada;

    private Double latitud;
    private Double longitud;

    @ManyToOne
    @JoinColumn(name = "idruta")
    private Ruta ruta;

    // Constructores
    public Coordenadas() {}

    public Coordenadas(Long idcoordenada, Double latitud, Double longitud, Ruta ruta) {
        this.idcoordenada = idcoordenada;
        this.latitud = latitud;
        this.longitud = longitud;
        this.ruta = ruta;
    }

    // Getters y Setters
    public Long getIdcoordenada() {
        return idcoordenada;
    }

    public void setIdcoordenada(Long idcoordenada) {
        this.idcoordenada = idcoordenada;
    }

    public Double getLatitud() {
        return latitud;
    }

    public void setLatitud(Double latitud) {
        this.latitud = latitud;
    }

    public Double getLongitud() {
        return longitud;
    }

    public void setLongitud(Double longitud) {
        this.longitud = longitud;
    }

    public Ruta getRuta() {
        return ruta;
    }

    public void setRuta(Ruta ruta) {
        this.ruta = ruta;
    }
}

