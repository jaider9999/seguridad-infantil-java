package uts.edu.java.corte2.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uts.edu.java.corte2.modelo.Menor;
import uts.edu.java.corte2.repositorio.MenorRepositorio;

@Service
@Transactional
public class MenorServicio implements IMenorServicio {

    @Autowired
    private MenorRepositorio menorRepositorio;

    @Override
    public List<Menor> getMenores() {
        return menorRepositorio.findAll();
    }

    @Override
    public Menor listarId(Long id) {
        return menorRepositorio.findById(id).orElse(null);
    }

    @Override
    public Menor save(Menor menor) {
        return menorRepositorio.save(menor);
    }

    @Override
    public void delete(Long id) {
        menorRepositorio.deleteById(id);
    }
}
