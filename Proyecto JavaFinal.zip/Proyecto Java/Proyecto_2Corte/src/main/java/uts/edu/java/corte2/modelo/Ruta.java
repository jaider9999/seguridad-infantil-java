package uts.edu.java.corte2.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "ruta")
public class Ruta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idruta;

    @Column(name = "nombreruta", nullable = false, length = 100)
    private String nombreruta;

    // Constructor vacío
    public Ruta() {}

    // Constructor con parámetros
    public Ruta(Long idruta, String nombreruta) {
        this.idruta = idruta;
        this.nombreruta = nombreruta;
    }

    // Getters y Setters
    public Long getIdruta() {
        return idruta;
    }

    public void setIdruta(Long idruta) {
        this.idruta = idruta;
    }

    public String getNombreruta() {
        return nombreruta;
    }

    public void setNombreruta(String nombreruta) {
        this.nombreruta = nombreruta;
    }
}
