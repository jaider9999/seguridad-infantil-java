package uts.edu.java.corte2.servicio;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uts.edu.java.corte2.modelo.Coordenadas;
import uts.edu.java.corte2.repositorio.CoordenadasRepositorio;

@Service
public class CoordenadasServicio implements ICoordenadasServicio {

    @Autowired
    private CoordenadasRepositorio coordenadasRepositorio;

    @Override
    public List<Coordenadas> listarTodas() {
        return coordenadasRepositorio.findAll();
    }

    @Override
    public Coordenadas listarPorId(Long id) {
        return coordenadasRepositorio.findById(id).orElse(null);
    }

    @Override
    public void guardar(Coordenadas coordenadas) {
        coordenadasRepositorio.save(coordenadas);
    }

    @Override
    public void eliminar(Long id) {
        coordenadasRepositorio.deleteById(id);
    }
}
