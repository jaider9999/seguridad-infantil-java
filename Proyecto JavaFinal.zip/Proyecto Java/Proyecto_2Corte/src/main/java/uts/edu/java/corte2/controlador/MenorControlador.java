package uts.edu.java.corte2.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import uts.edu.java.corte2.modelo.Menor;
import uts.edu.java.corte2.servicio.MenorServicio;
import uts.edu.java.corte2.servicio.DispositivoServicio;

@Controller
@RequestMapping("/views/menor")
public class MenorControlador {

    @Autowired
    private MenorServicio menorServicio;

    @Autowired
    private DispositivoServicio dispositivoServicio;

    // Listar menores
    @RequestMapping("/")
    public String verIndex(Model model) {
        List<Menor> listaMenores = menorServicio.getMenores();
        model.addAttribute("listaMenores", listaMenores);
        return "/views/menor/menor";
    }

    // Formulario nuevo menor
    @RequestMapping("/new")
    public String mostrarPaginaNuevoMenor(Model model) {
        Menor menor = new Menor();
        model.addAttribute("menor", menor);
        model.addAttribute("listaDispositivos", dispositivoServicio.getDispositivos());
        return "/views/menor/nuevo_menor";
    }

    // Guardar menor
    @PostMapping("/save")
    public String saveMenor(Menor menor, Model model) {
        menorServicio.save(menor);
        return "redirect:/views/menor/";
    }

    // Editar menor
    @GetMapping("/listar/{id}")
    public String listarId(@PathVariable Long id, Model model) {
        model.addAttribute("menor", menorServicio.listarId(id));
        model.addAttribute("listaDispositivos", dispositivoServicio.getDispositivos());
        return "/views/menor/editar_menor";
    }

    // Eliminar menor
    @RequestMapping("/delete/{id}")
    public String deleteMenor(@PathVariable(name = "id") Long id) {
        menorServicio.delete(id);
        return "redirect:/views/menor/";
    }
}
