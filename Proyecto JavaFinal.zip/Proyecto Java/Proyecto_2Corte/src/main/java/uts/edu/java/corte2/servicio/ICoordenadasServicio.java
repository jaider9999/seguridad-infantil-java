package uts.edu.java.corte2.servicio;

import java.util.List;
import uts.edu.java.corte2.modelo.Coordenadas;

public interface ICoordenadasServicio {
    List<Coordenadas> listarTodas();
    Coordenadas listarPorId(Long id);
    void guardar(Coordenadas coordenadas);
    void eliminar(Long id);
}

