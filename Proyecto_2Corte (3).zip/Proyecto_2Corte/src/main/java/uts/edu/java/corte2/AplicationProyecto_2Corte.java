package uts.edu.java.corte2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicationProyecto_2Corte {
	public static void main(String[] args) {
	    SpringApplication.run(AplicationProyecto_2Corte.class, args);
	  }
}
