package uts.edu.java.corte2.modelo;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "alerta")
public class Alerta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idalerta;

    private String tipoalerta;
    private LocalDateTime hora;
    private String ubicacion;
    private String estadoalarma;

    @ManyToOne
    @JoinColumn(name = "iddispositivo")
    private Dispositivo dispositivo;

    @ManyToOne
    @JoinColumn(name = "idniño")
    private Menor menor;

    public Alerta() {}

    public Alerta(Long idalerta, String tipoalerta, LocalDateTime hora, String ubicacion,
                  String estadoalarma, Dispositivo dispositivo, Menor menor) {
        this.idalerta = idalerta;
        this.tipoalerta = tipoalerta;
        this.hora = hora;
        this.ubicacion = ubicacion;
        this.estadoalarma = estadoalarma;
        this.dispositivo = dispositivo;
        this.menor = menor;
    }

    // Getters y Setters
    public Long getIdalerta() { return idalerta; }
    public void setIdalerta(Long idalerta) { this.idalerta = idalerta; }

    public String getTipoalerta() { return tipoalerta; }
    public void setTipoalerta(String tipoalerta) { this.tipoalerta = tipoalerta; }

    public LocalDateTime getHora() { return hora; }
    public void setHora(LocalDateTime hora) { this.hora = hora; }

    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }

    public String getEstadoalarma() { return estadoalarma; }
    public void setEstadoalarma(String estadoalarma) { this.estadoalarma = estadoalarma; }

    public Dispositivo getDispositivo() { return dispositivo; }
    public void setDispositivo(Dispositivo dispositivo) { this.dispositivo = dispositivo; }

    public Menor getMenor() { return menor; }
    public void setMenor(Menor menor) { this.menor = menor; }
}
