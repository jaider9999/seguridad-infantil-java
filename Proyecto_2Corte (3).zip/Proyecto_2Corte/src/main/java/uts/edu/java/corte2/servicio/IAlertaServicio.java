package uts.edu.java.corte2.servicio;

import java.util.List;
import uts.edu.java.corte2.modelo.Alerta;

public interface IAlertaServicio {
    List<Alerta> listarTodas();
    Alerta listarPorId(Long id);
    void guardar(Alerta alerta);
    void eliminar(Long id);
}
