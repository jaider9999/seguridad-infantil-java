package uts.edu.java.corte2.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import uts.edu.java.corte2.modelo.Dispositivo;
import uts.edu.java.corte2.repositorio.DispositivoRepositorio;

@Service
@Transactional
public class DispositivoServicio implements IDispositivoServicio {

    @Autowired
    private DispositivoRepositorio dispositivoRepositorio;

    @Override
    public List<Dispositivo> getDispositivos() {
        return dispositivoRepositorio.findAll();
    }

    @Override
    public Dispositivo listarId(Long id) {
        return dispositivoRepositorio.findById(id).orElse(null);
    }

    @Override
    public Dispositivo save(Dispositivo dispositivo) {
        return dispositivoRepositorio.save(dispositivo);
    }

    @Override
    public void delete(Long id) {
        dispositivoRepositorio.deleteById(id);
    }
}

