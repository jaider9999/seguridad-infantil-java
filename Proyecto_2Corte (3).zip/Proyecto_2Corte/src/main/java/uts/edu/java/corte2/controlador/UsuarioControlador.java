  package uts.edu.java.corte2.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import uts.edu.java.corte2.modelo.Usuario;
import uts.edu.java.corte2.servicio.UsuarioServicio;

@Controller
@RequestMapping("/views/usuario")
public class UsuarioControlador {

    @Autowired
    private UsuarioServicio usuarioServicio;

    // ✅ Listar todos los usuarios
    @GetMapping("/")
    public String verIndex(Model model) {
        List<Usuario> listaUsuarios = usuarioServicio.getUsuarios();
        model.addAttribute("listaUsuarios", listaUsuarios);
        return "/views/usuario/usuario"; // tu archivo HTML
    }

    // ✅ Mostrar formulario de nuevo usuario
    @GetMapping("/new")
    public String mostrarPaginaNuevoUsuario(Model model) {
        Usuario usuario = new Usuario();
        model.addAttribute("usuario", usuario);
        return "/views/usuario/nuevo_usuario";
    }

    // ✅ Guardar usuario
    @PostMapping("/save")
    public String saveUsuario(@ModelAttribute Usuario usuario) {
        usuarioServicio.save(usuario);
        return "redirect:/views/usuario/";
    }

    // ✅ Editar usuario
    @GetMapping("/edit/{id}")
    public String editarUsuario(@PathVariable("id") long id, Model model) {
        Usuario usuario = usuarioServicio.listarId(id);
        model.addAttribute("usuario", usuario);
        return "/views/usuario/editar_usuario";
    }

    // ✅ Eliminar usuario
    @GetMapping("/delete/{id}")
    public String deleteUsuario(@PathVariable("id") long id) {
        usuarioServicio.delete(id);
        return "redirect:/views/usuario/";
    }
}



