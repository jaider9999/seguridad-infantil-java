package uts.edu.java.corte2.servicio;

import java.util.List;
import uts.edu.java.corte2.modelo.Menor;

public interface IMenorServicio {

    // Listar todos los menores
    List<Menor> getMenores();

    // Buscar por ID
    Menor listarId(Long id);

    // Crear o actualizar menor
    Menor save(Menor menor);

    // Eliminar menor
    void delete(Long id);
}
