package uts.edu.java.corte2.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "rol")
public class Rol {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idrol;

    @Column(nullable = false, length = 50)
    private String nombre;

    // 🔗 Relación opcional con usuarios (uno a muchos)
    // Si no la necesitas aún, puedes comentarla
    /*
    @OneToMany(mappedBy = "rol")
    private List<Usuario> usuarios;
    */

    // ----- Constructores -----
    public Rol() {}

    public Rol(int idrol, String nombre) {
        this.idrol = idrol;
        this.nombre = nombre;
    }

    // ----- Getters y Setters -----
    public int getIdrol() {
        return idrol;
    }

    public void setIdrol(int idrol) {
        this.idrol = idrol;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Rol [idrol=" + idrol + ", nombre=" + nombre + "]";
    }
}
