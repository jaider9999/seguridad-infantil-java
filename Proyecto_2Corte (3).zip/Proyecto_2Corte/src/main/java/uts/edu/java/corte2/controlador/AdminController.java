package uts.edu.java.corte2.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import uts.edu.java.corte2.repositorio.UsuarioRepositorio;
import uts.edu.java.corte2.repositorio.DispositivoRepositorio;
import uts.edu.java.corte2.repositorio.RutaRepositorio;

@Controller
public class AdminController {

    @Autowired
    private UsuarioRepositorio usuarioRepo;

    @Autowired
    private DispositivoRepositorio dispositivoRepo;

    @Autowired
    private RutaRepositorio rutaRepo;

    @GetMapping("/admin/panel")
    public String panelAdmin(Model model) {
        model.addAttribute("usuarios", usuarioRepo.findAll());
        model.addAttribute("dispositivos", dispositivoRepo.findAll());
        model.addAttribute("rutas", rutaRepo.findAll());
        return "admin/panel"; // busca templates/admin/panel.html
    }
}

