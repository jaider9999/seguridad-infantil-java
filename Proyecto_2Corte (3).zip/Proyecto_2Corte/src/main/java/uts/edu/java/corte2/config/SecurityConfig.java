package uts.edu.java.corte2.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/login", "/css/**", "/js/**", "/img/**").permitAll()
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .requestMatchers("/padre/**").hasRole("PADRE")
                .requestMatchers("/profesor/**").hasRole("PROFESOR")
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .successHandler(customAuthenticationSuccessHandler()) // 🔥 Redirección personalizada
                .permitAll()
            )
            .logout(logout -> logout
                    .logoutUrl("/logout")   // <- Aquí se define el endpoint de cierre de sesión
                    .logoutSuccessUrl("/login?logout") // Redirige al login después de cerrar sesión
                    .permitAll()
                );

        return http.build();
    }

    // 🔐 Usuarios en memoria
    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder passwordEncoder) {
        UserDetails admin = User.withUsername("admin")
                .password(passwordEncoder.encode("admin123"))
                .roles("ADMIN")
                .build();

        UserDetails padre = User.withUsername("padre")
                .password(passwordEncoder.encode("padre123"))
                .roles("PADRE")
                .build();

        UserDetails profesor = User.withUsername("profesor")
                .password(passwordEncoder.encode("profe123"))
                .roles("PROFESOR")
                .build();

        return new InMemoryUserDetailsManager(admin, padre, profesor);
    }

    // 🔐 Encriptador de contraseñas
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // 🔁 Redirección según rol
    @Bean
    public AuthenticationSuccessHandler customAuthenticationSuccessHandler() {
        return (request, response, authentication) -> {
            var authorities = authentication.getAuthorities();
            String redirectUrl = "/home";

            if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
                redirectUrl = "/admin/panel";
            } else if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_PADRE"))) {
                redirectUrl = "/padre/panel";
            } else if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_PROFESOR"))) {
                redirectUrl = "/profesor/panel";
            }

            response.sendRedirect(redirectUrl);
        };
    }
}


