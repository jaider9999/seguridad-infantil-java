package uts.edu.java.corte2.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import uts.edu.java.corte2.servicio.IRutaServicio; // ajusta según tu paquete

@Controller
public class ProfesorController {

    @Autowired
    private IRutaServicio rutaServicio;

    @GetMapping("/profesor/panel")
    public String panelProfesor(Model model) {
        model.addAttribute("rutas", rutaServicio.listarTodas());
        return "profesor/panel"; // se carga tu HTML panel.html
    }
}
