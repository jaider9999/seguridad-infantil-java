package uts.edu.java.corte2.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "dispositivo")
public class Dispositivo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long iddispositivo;

    private String tipodispositivo;
    private String estadodispositivo;
	public Long getIddispositivo() {
		return iddispositivo;
	}
	public void setIddispositivo(Long iddispositivo) {
		this.iddispositivo = iddispositivo;
	}
	public String getTipodispositivo() {
		return tipodispositivo;
	}
	public void setTipodispositivo(String tipodispositivo) {
		this.tipodispositivo = tipodispositivo;
	}
	public String getEstadodispositivo() {
		return estadodispositivo;
	}
	public void setEstadodispositivo(String estadodispositivo) {
		this.estadodispositivo = estadodispositivo;
	}

    
}

