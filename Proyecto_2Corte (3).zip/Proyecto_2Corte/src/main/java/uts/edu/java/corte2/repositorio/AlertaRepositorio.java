package uts.edu.java.corte2.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uts.edu.java.corte2.modelo.Alerta;

@Repository
public interface AlertaRepositorio extends JpaRepository<Alerta, Long> {
}

