package uts.edu.java.corte2.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import uts.edu.java.corte2.modelo.Dispositivo;
import uts.edu.java.corte2.servicio.DispositivoServicio;

@Controller
@RequestMapping("/views/dispositivo")
public class DispositivoControlador {

    @Autowired
    private DispositivoServicio dispositivoServicio;

    // Listar dispositivos
    @RequestMapping("/")
    public String verIndex(Model model) {
        List<Dispositivo> listaDispositivos = dispositivoServicio.getDispositivos();
        model.addAttribute("listaDispositivos", listaDispositivos);
        return "/views/dispositivo/dispositivo";
    }

    // Formulario nuevo dispositivo
    @RequestMapping("/new")
    public String mostrarPaginaNuevoDispositivo(Model model) {
        Dispositivo dispositivo = new Dispositivo();
        model.addAttribute("dispositivo", dispositivo);
        return "/views/dispositivo/nuevo_dispositivo";
    }

    // Guardar dispositivo
    @PostMapping("/save")
    public String saveDispositivo(Dispositivo dispositivo, Model model) {
        dispositivoServicio.save(dispositivo);
        return "redirect:/views/dispositivo/";
    }

    // Editar dispositivo
    @GetMapping("/listar/{id}")
    public String listarId(@PathVariable Long id, Model model) {
        model.addAttribute("dispositivo", dispositivoServicio.listarId(id));
        return "/views/dispositivo/editar_dispositivo";
    }

    // Eliminar dispositivo
    @RequestMapping("/delete/{id}")
    public String deleteDispositivo(@PathVariable(name = "id") Long id) {
        dispositivoServicio.delete(id);
        return "redirect:/views/dispositivo/";
    }
}

