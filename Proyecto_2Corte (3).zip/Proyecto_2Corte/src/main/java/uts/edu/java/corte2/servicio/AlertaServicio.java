package uts.edu.java.corte2.servicio;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uts.edu.java.corte2.modelo.Alerta;
import uts.edu.java.corte2.repositorio.AlertaRepositorio;

@Service
public class AlertaServicio implements IAlertaServicio {

    @Autowired
    private AlertaRepositorio alertaRepositorio;

    @Override
    public List<Alerta> listarTodas() {
        return alertaRepositorio.findAll();
    }

    @Override
    public Alerta listarPorId(Long id) {
        return alertaRepositorio.findById(id).orElse(null);
    }

    @Override
    public void guardar(Alerta alerta) {
        alertaRepositorio.save(alerta);
    }

    @Override
    public void eliminar(Long id) {
        alertaRepositorio.deleteById(id);
    }
}
