package uts.edu.java.corte2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto2CorteApplicationTests {

	@Test
	void contextLoads() {
	}

}
